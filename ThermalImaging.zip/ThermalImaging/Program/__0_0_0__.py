import cv2
import numpy as np

x_mouse = 0
y_mouse = 0


def get_mouse_position(event, x, y,*args):
    if(event == cv2.EVENT_MOUSEMOVE):
        global x_mouse, y_mouse
        x_mouse = x
        y_mouse = y
        # print(x_mouse, y_mouse)

thermal_cam = cv2.VideoCapture(0)
thermal_cam.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
thermal_cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

thermal_cam.set(cv2.CAP_PROP_FOURCC,cv2.VideoWriter.fourcc('V','1','6',' '))
thermal_cam.set(cv2.CAP_PROP_CONVERT_RGB, 0)

grabbed, frame = thermal_cam.read()
cv2.imshow("Thermal Camera", frame)

cv2.setMouseCallback("Thermal Camera", get_mouse_position)

while True:
    (grabbed, thermal_frame) = thermal_cam.read()
    print(thermal_frame)
    temp_ptr = thermal_frame[y_mouse, x_mouse]
    print(temp_ptr)
    temp_ptr = (temp_ptr/100) * 9/5 - 459.67
    print(temp_ptr)

    cv2.normalize(thermal_frame, thermal_frame, 0, 255, cv2.NORM_MINMAX)
    thermal_frame = cv2.applyColorMap(thermal_frame, cv2.COLORMAP_HOT)
    cv2.circle(thermal_frame, (x_mouse, y_mouse), 5, (0, 0, 255), 2)
    cv2.putText(thermal_frame, "{:.1f}F".format(temp_ptr), (x_mouse, y_mouse), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 255), 2)
    cv2.imshow("Thermal Camera", thermal_frame)
    
    if cv2.waitKey(1) & 0xFF == ord("t"):
        break
    if cv2.waitKey(1) & 0xFF == ord("T"):
        break  

thermal_cam.release()
cv2.destroyAllWindows()


# import cv2
# import numpy as np
# import time

# def get_color_code_at_position(position, rgb):
#     x, y = position
#     print(x,y)
#     color = rgb[y, x]
#     r, g, b = color
#     temperature = (6823.3 * r + 3525 * g + 449 * b) / 10000
#     return temperature

# def get_mouse_position(event, x, y, *args):
#     global mouse_position, color_code
#     print(mouse_position)
#     if event == cv2.EVENT_MOUSEMOVE:
#         mouse_position = np.array([x, y]).astype(np.uint8)
#         color_code = get_color_code_at_position(mouse_position, rgb)

# cap = cv2.VideoCapture(0)
# colormap = cv2.COLORMAP_JET

# mouse_position = np.zeros(2, dtype=np.uint8)
# color_code = 0.0

# while True:
#     ret, frame = cap.read()
#     grayscale = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
#     rgb = cv2.applyColorMap(grayscale, colormap)
#     print(frame.shape)
#     cv2.imshow("Frame", rgb)
#     cv2.setMouseCallback("Frame", get_mouse_position)

#     if mouse_position[0] > 0 and mouse_position[1] > 0:
#         temp_ptr = frame[mouse_position[1], mouse_position[0]]
#         temp_celsius = get_color_code_at_position(mouse_position, rgb)
#         temp_fahrenheit = (temp_celsius * 9 / 5) + 32

#         # Create a black overlay to display text
#         overlay = np.zeros_like(rgb)

#         # Define the text to be displayed
#         text = "{:.1f}F".format(temp_fahrenheit)

#         # Get the size of the text
#         (text_width, text_height), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 1.0, 2)

#         text_x = mouse_position[0]
#         text_y = mouse_position[1]
        
#         print(text_x, text_y)

#         print(mouse_position)
#         print("---")
#         # Put the text on the overlay
#         cv2.putText(overlay, text, (text_x, text_y), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 0, 255), 2)
        
#         # Blend the overlay with the frame
#         frame_with_text = cv2.addWeighted(frame, 1, overlay, 0.5, 0)

#         # Show the frame with the text
#         cv2.imshow("Frame", frame_with_text)
#     else:
#         cv2.imshow("Frame", rgb)

#     # time.sleep(1)

#     if cv2.waitKey(1) & 0xFF == ord("t"):
#         break
#     if cv2.waitKey(1) & 0xFF == ord("T"):
#         break

# cap.release()
# cv2.destroyAllWindows()

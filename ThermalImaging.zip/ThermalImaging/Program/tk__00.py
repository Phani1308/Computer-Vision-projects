# import tkinter as tk

# def on_close():
#     root.destroy()

# root = tk.Tk()
# root.title("Two Horizontal Splits")

# # Create a PanedWindow with two panes (splits) arranged horizontally
# paned_window = tk.PanedWindow(orient=tk.HORIZONTAL, sashrelief=tk.RAISED)
# paned_window.pack(fill=tk.BOTH, expand=True)

# # Create widgets for the first split (left side)
# left_frame = tk.Frame(paned_window, bg="blue")
# left_label = tk.Label(left_frame, text="Left Split", bg="blue", fg="white")
# left_label.pack(padx=20, pady=20, fill=tk.BOTH, expand=True)
# paned_window.add(left_frame)

# # Create widgets for the second split (right side)
# right_frame = tk.Frame(paned_window, bg="green")
# right_label = tk.Label(right_frame, text="Right Split", bg="green", fg="white")
# right_label.pack(padx=20, pady=20, fill=tk.BOTH, expand=True)
# paned_window.add(right_frame)

# root.protocol("WM_DELETE_WINDOW", on_close)
# root.mainloop()

# ------------------------------------------------------------------------------------ #

# # import cv2
# # import numpy as np

# # def get_mouse_position(event, x, y,*args):
  
# #   global mouse_position
# #   if event == cv2.EVENT_MOUSEMOVE:
# #     mouse_position = np.array([x, y]).astype(np.uint8)
# #     print(mouse_position)

# # cap = cv2.VideoCapture(0)
# # colormap = cv2.COLORMAP_JET

# # while True:
# #   ret, frame = cap.read()
# #   grayscale = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
# #   rgb = cv2.applyColorMap(grayscale, colormap)
# #   cv2.imshow("Frame", rgb)
# #   cv2.setMouseCallback("Frame", get_mouse_position)
# #   if cv2.waitKey(1) & 0xFF == ord("q"):
# #     break

# # cap.release()
# # cv2.destroyAllWindows()
import cv2
import math

cv2.namedWindow("Thermal Motion Imaging", cv2.WND_PROP_FULLSCREEN)
cv2.setWindowProperty("Thermal Motion Imaging", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

cvvc = cv2.VideoCapture(0)
cmap = cv2.COLORMAP_RAINBOW

pX, pY = -1,-1

def func__RGB2K(RGB):
    # Source : https://gist.github.com/SaintWacko/803ef2abe8c835f7c886c0f6df726baf (RGB -> Kelvin Temperature)
    R, G, B = [I / 255.0 for I in RGB]
    X0 = R * 0.649926 + G * 0.103455 + B * 0.197109
    Y0 = R * 0.234327 + G * 0.743075 + B * 0.022598
    Z0 = R * 0.000000 + G * 0.053077 + B * 1.035763
    X1 = R * 0.4124564 + G * 0.3575761 + B * 0.1804375
    Y1 = R * 0.2126729 + G * 0.7151522 + B * 0.0721750
    Z1 = R * 0.0193339 + G * 0.1191920 + B * 0.9503041
    X = (X0+X1) / 2
    Y = (Y0+Y1) / 2
    Z = (Z0+Z1) / 2
    X = X / (X + Y + Z)
    Y = Y / (X + Y + Z)
    N = (X - 0.3366) / (Y - 0.1735)
    K = (-949.86315 + 6253.80338 * math.e**(-N / 0.92159) + 28.70599 * math.e**(-N / 0.20039) + 0.00004 * math.e**(-N / 0.07125))
    N = (X - 0.3356) / (Y - 0.1691) if K > 50000 else N
    K = 36284.48953 + 0.00228 * math.e**(-N / 0.07861) + (5.4535 * 10**-36) * math.e**(-N / 0.01543) if K > 50000 else K
    return K

def func__pXpY(args__event, args__x, args__y, *args):
    global pX, pY
    if args__event == cv2.EVENT_MOUSEMOVE:
        pX, pY = args__x, args__y

while True:
    cv2.setMouseCallback("Thermal Motion Imaging", func__pXpY)

    __, XY = cvvc.read()
    XY = cv2.applyColorMap(XY, cmap)

    if not __:
        break

    title = "### Thermal Motion Imaging ###"
    len__title = len(title)
    sub_title0 = "*** Surge Classes || Deep Learning Functional Project || Thermal Motion Imaging ***" 
    len__sub_title0 = len(sub_title0)
    sub_title1 = "~ ~ ~ < K.V.N. Aditya | P. Sai Karthik | P. Phanindra | M. Venu | B. Lokesh > ~ ~ ~" 
    len__sub_title1 = len(sub_title1)
    sub_title2 = "!!! Only for Experimental Purpose ||| Not for Production !!!" 
    len__sub_title2 = len(sub_title2)
    to_terminate = "`Press `esc` key to terminate the Program`"
    len__to_terminate = len(to_terminate)
    RGB = XY[pY-1, pX-1]
    tempK = func__RGB2K(RGB)
    tempK = str(tempK) + " K"
    len__tempK = len(tempK)

    cv2.rectangle(XY, (0,0), (XY.shape[1],100), (0,0,0), thickness=cv2.FILLED)
    cv2.rectangle(XY, (0,XY.shape[0]-20), (XY.shape[1],XY.shape[0]), (0,0,0), thickness=cv2.FILLED)
    cv2.putText(XY, title, ((XY.shape[1]//4)-(len__title//4) , (XY.shape[0] - XY.shape[0]) + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,0 , 255), 2)
    cv2.putText(XY, sub_title0, ((XY.shape[1]//8)-(len__sub_title0//8) , (XY.shape[0] - XY.shape[0]) + 40), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0,255 , 0), 1)
    cv2.putText(XY, sub_title1, ((XY.shape[1]//13)-(len__sub_title1//13) , (XY.shape[0] - XY.shape[0]) + 60), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255,255 , 255), 1)
    cv2.putText(XY, sub_title2, ((XY.shape[1]//3)-(len__sub_title2//3) , (XY.shape[0] - XY.shape[0]) + 80), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (0,0 , 255), 1)
    cv2.putText(XY, to_terminate, ((XY.shape[1]//3)-(len__to_terminate//3) + 60 , XY.shape[0] - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.2, (117,118 , 117), 1)
    if 0 <= pY < XY.shape[0] and 0 <= pX < XY.shape[1]:
        cv2.rectangle(XY, (0,XY.shape[0]-60), (XY.shape[1],XY.shape[0]-20), (255,255,255), thickness=cv2.FILLED)
        cv2.putText(XY, tempK, ((XY.shape[1]//4)-(len__tempK//4) , (XY.shape[0] - 25)), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 2)
    
    cv2.imshow("Thermal Motion Imaging", XY)

    if cv2.waitKey(1) & 0xFF == 27:
        break

cvvc.release()
cv2.destroyAllWindows()